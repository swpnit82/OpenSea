import { BigNumber, utils } from 'ethers'
import { useCallback, useEffect, useState } from 'react'
import { Box, Button, Flex, Grid, Heading, Input, Select } from 'theme-ui'
import { useAppState } from '../../state'
import { Token } from '..'


export type GalleryProps = {}
type StateOrder = 'price' | 'alpha'

const Gallery = () => {
  let { user, tokensOnSale } = useAppState()
  const updateTokensOnSale = useAppState(
    useCallback(({ updateTokensOnSale }) => updateTokensOnSale, [])
  )

  const [order, setOrder] = useState<StateOrder>('alpha')
  let [tokenData, setTokeata] = useState([] as any | undefined);
  useEffect(() => {
    console.log("user, tokensOnSale ", user, tokensOnSale);
    if (tokensOnSale)
      setTokeata([...tokensOnSale])

  }, [tokensOnSale])

  useEffect(() => {
    updateTokensOnSale()
  }, [updateTokensOnSale])

  let filteredData = [] as any
  const searchPlayer = (e: any) => {
    if (e.target.value) {
      filteredData = tokensOnSale?.filter(x => x.name.toLowerCase().includes(e.target.value.toLowerCase()));
      if (filteredData)
        setTokeata([...filteredData])
    }
    else {
      if (tokensOnSale)
        setTokeata([...tokensOnSale])
    }

    console.log("Search ", tokensOnSale);


  }

  const filterData = (e: any) => {
    if (e.target.value) {
      let [data, opt] = e.target.value.split("-");
      console.log(data, opt);
      if (data === "price") {
        tokenData = tokenData
          ?.sort((a: any, b: any) =>
            opt === 'asc'
              ? BigNumber.from(a.price)
                .toString()
                .localeCompare(BigNumber.from(b.price).toString(), undefined, { numeric: true })
              : BigNumber.from(b.price)
              .toString()
              .localeCompare(BigNumber.from(a.price).toString(), undefined, { numeric: true })
          )
          console.log(tokenData);
          
      }


    }

  }

  return (
    <Box>
      <Heading as="h1">Marketplace</Heading>
      <Flex sx={{ alignItems: 'center' }} mb={3}>
        <Heading as="h3" sx={{ color: 'lightGray' }}>
          Order:
        </Heading>
        <Flex ml={3}>
          <Button
            mr={2}
            onClick={() => setOrder('alpha')}
            variant="filter"
            disabled={order === 'alpha'}
          >
            Alphabetically
          </Button>
          <Button onClick={() => setOrder('price')} variant="filter" disabled={order === 'price'}>
            Price
          </Button>
        </Flex>
      </Flex>
      <div style={{ marginBottom: "20px" }}>
        <Select defaultValue="Hello" onChange={filterData}>
          <option value="">Select Filter</option>
          <option value="name-asc">Name(A-Z)</option>
          <option value="name-des">Name(Z-A)</option>
          <option value="price-asc">Price(Low-High)</option>
          <option value="price-des">Price(High-Low)</option>
        </Select>
      </div>
      <Flex ml={3}>

      </Flex>

      <Flex >
        <Box p={2} bg="primary" sx={{ flex: '1 1 auto' }}>
          <Input placeholder="Search" onChange={searchPlayer} />
        </Box>

      </Flex>
      <Grid gap={4} columns={['1fr 1fr', '1fr 1fr', '1fr 1fr 1fr']}>
        {tokenData
          ?.sort((a: any, b: any) =>
            order === 'alpha'
              ? BigNumber.from(a.id)
                .toString()
                .localeCompare(BigNumber.from(b.id).toString(), undefined, { numeric: true })
              : Number(utils.formatEther(a.price.sub(b.price)))
          )
          .map((i: any, index: number) => (
            <Token onBuy={!user?.ownedTokens.find(t => t.id === i.id)} token={i} key={index} />
          ))}
      </Grid>
    </Box>
  )
}

export { Gallery }
