import { render } from '@testing-library/react'
import { Gallery } from './Gallery'

test(`Renders Gallery`, () => {
  render(<Gallery />)
})
