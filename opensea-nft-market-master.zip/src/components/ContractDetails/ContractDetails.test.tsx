import { render } from '@testing-library/react'
import { ContractDetails } from './ContractDetails'

test(`Renders ContractDetails`, () => {
  render(<ContractDetails />)
})
