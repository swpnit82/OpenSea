import { render } from '@testing-library/react'
import { UserMenu } from './UserMenu'

test(`Renders UserMenu`, () => {
  render(<UserMenu />)
})
